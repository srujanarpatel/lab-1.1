from transformers import GPT2LMHeadModel, GPT2Tokenizer
import torch

# Load tokenizer and model
model_name = "gpt2"
tokenizer = GPT2Tokenizer.from_pretrained(model_name)
model = GPT2LMHeadModel.from_pretrained(model_name)

device = torch.device("cpu")
model.to(device)

# Prompt from user
prompt = input("Enter your story idea: ").strip()

# Use a default prompt if user enters nothing
if not prompt:
    prompt = "A wizard who lost his powers in a modern city"

# Encode input
inputs = tokenizer.encode(prompt, return_tensors="pt").to(device)

# Generate output
outputs = model.generate(
    inputs,
    max_length=300,  # Increased for ~200 words
    num_return_sequences=1,
    no_repeat_ngram_size=2,
    early_stopping=True,
    temperature=0.9,
    top_k=50,
    top_p=0.95
)

# Decode result
story = tokenizer.decode(outputs[0], skip_special_tokens=True)

# Optional: Limit to exactly 200 words
story_words = story.split()
story = ' '.join(story_words[:200])

print("\n📝 Generated Story (~200 words):\n")
print(story)
