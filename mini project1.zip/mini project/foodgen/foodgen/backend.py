from flask import Flask, render_template, request
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

app = Flask(__name__)

# Expanded food data with Indian dishes
data = {
    'Food': [
        'Pizza', 'Pasta', 'Burger', 'Sushi', 'Salad', 'Tacos', 'Pancakes', 'Sushi Roll', 'Lasagna',
        'Biryani', 'Butter Chicken', 'Paneer Tikka', 'Chole Bhature', 'Dosa', 'Idli', 'Samosa', 'Gulab Jamun','papad masala'
    ],
    'Ingredients': [
        'dough, cheese, tomato, pepperoni',
        'pasta, tomato sauce, garlic, cheese',
        'beef, lettuce, tomato, cheese, bun',
        'fish, rice, seaweed, wasabi, soy sauce',
        'lettuce, tomato, cucumber, dressing',
        'corn, meat, lettuce, cheese, salsa',
        'flour, eggs, milk, sugar, syrup',
        'rice, fish, avocado, seaweed, soy sauce',
        'pasta, tomato sauce, cheese, meat',
        'rice, chicken, spices, yogurt',
        'chicken, butter, cream, tomatoes, spices',
        'paneer, yogurt, spices, bell peppers, onion',
        'chickpeas, flour, spices, oil',
        'rice, lentils, spices, coconut, ghee',
        'rice, lentils, fermentation, coconut chutney',
        'potatoes, peas, flour, spices, oil',
        'milk, sugar, cardamom, rose water, saffron',
        'papad,onion,tomato,coconut,chilli powder'
    ],
    'Category': [
        'Italian', 'Italian', 'American', 'Japanese', 'Healthy', 'Mexican', 'American', 'Japanese', 'Italian',
        'Indian', 'Indian', 'Indian', 'Indian', 'Indian', 'Breakfast', 'Breakfast', 'Indian','Indian'
    ]
}

# Create DataFrame
df = pd.DataFrame(data)

# Function to get food recommendations based on a given food item and category filter
def recommend_food(input_food, category_filter):
    tfidf_vectorizer = TfidfVectorizer(stop_words='english')
    tfidf_matrix = tfidf_vectorizer.fit_transform(df['Ingredients'])

    cosine_sim = cosine_similarity(tfidf_matrix, tfidf_matrix)
    idx = df[df['Food'] == input_food].index[0]

    sim_scores = list(enumerate(cosine_sim[idx]))
    sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)
    sim_scores = sim_scores[1:6]

    food_indices = [i[0] for i in sim_scores]
    recommended_foods = df['Food'].iloc[food_indices].tolist()

    # Filter by category if selected
    if category_filter != "All":
        recommended_foods = [food for food in recommended_foods if df.loc[df['Food'] == food, 'Category'].values[0] == category_filter]

    return recommended_foods

@app.route("/", methods=["GET", "POST"])
def index():
    recommended_foods = []
    input_food = "Pizza"  # Default food to recommend if no input is provided
    category_filter = "All"  # Default category

    if request.method == "POST":
        input_food = request.form["food"]
        category_filter = request.form["category"]
        recommended_foods = recommend_food(input_food, category_filter)

    return render_template("index.html", recommended_foods=recommended_foods, input_food=input_food, category_filter=category_filter)

if __name__ == "__main__":
    app.run(debug=True)
